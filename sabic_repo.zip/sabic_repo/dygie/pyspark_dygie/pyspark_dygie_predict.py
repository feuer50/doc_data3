# -*- coding: utf-8 -*-
"""
Created on Sun Oct 11 17:58:19 2020

@author: SU20165358
"""


from typing import List, Iterator, Optional
import sys
import json

from allennlp.__main__ import run
from allennlp.common.checks import check_for_gpu, ConfigurationError
from allennlp.common.file_utils import cached_path
from allennlp.common.util import lazy_groups_of
from allennlp.models.archival import load_archive
from allennlp.predictors.predictor import Predictor, JsonDict
from allennlp.data import Instance

from allennlp.common.util import import_module_and_submodules
import_module_and_submodules('dygie')



def _get_predictor(archive_file, cuda_device, weights_file, overrides, infer_predictor, dataset_reader_choice) -> Predictor:
    check_for_gpu(cuda_device)
    archive = load_archive(archive_file,
                           weights_file=weights_file,
                           cuda_device=cuda_device,
                           overrides=overrides)

    return Predictor.from_archive(archive, infer_predictor,
                                  dataset_reader_to_load=dataset_reader_choice)


class _PredictManager:

    def __init__(self,
                 predictor,
                 input_file,
                 batch_size,
                 print_to_console,
                 has_dataset_reader):

        self._predictor = predictor
        self._input_file = input_file
        self._batch_size = batch_size
        self._print_to_console = print_to_console
        if has_dataset_reader:
            self._dataset_reader = predictor._dataset_reader # pylint: disable=protected-access
        else:
            self._dataset_reader = None

    def _predict_instances(self, batch_data: List[Instance]) -> Iterator[str]:
        if len(batch_data) == 1:
            results = [self._predictor.predict_instance(batch_data[0])]
        else:
            results = self._predictor.predict_batch_instance(batch_data)
        for output in results:
            yield self._predictor.dump_line(output)


    def _get_instance_data(self) -> Iterator[Instance]:
        if self._input_file == "-":
            raise ConfigurationError("stdin is not an option when using a DatasetReader.")
        elif self._dataset_reader is None:
            raise ConfigurationError("To generate instances directly, pass a DatasetReader.")
        else:
            yield from self._dataset_reader.read(self._input_file)

    def run(self):
        has_reader = self._dataset_reader is not None
        op_lst = []
        if has_reader:
            for batch in lazy_groups_of(self._get_instance_data(), self._batch_size):
                for model_input_instance, result in zip(batch, self._predict_instances(batch)):
                    op_lst.append(json.loads(result))
                    
        else:
            pass
            
        return(op_lst)
            

def predict_spark(archive_file, input_file, batch_size=1, cuda_device=-1, dataset_reader_choice='validation', overrides='', infer_predictor='dygie', silent=False, use_dataset_reader=True, weights_file=None):
    
    predictor = _get_predictor(archive_file, cuda_device, weights_file, overrides, infer_predictor, dataset_reader_choice)

    manager = _PredictManager(predictor,
                              input_file,
                              batch_size,
                              silent,
                              use_dataset_reader)
    output = manager.run()
    return(output)



#with open('C:/Users/su20165358/sushil/projects/sabic/IE/dygiepp_test/data/scierc/processed_data/json/test.json', 'r') as f:
#    input_file = f.readlines()
#input_file = [json.loads(i) for i in input_file]
#
#dy_op = predict_spark(archive_file='./pretrained/scierc.tar.gz', input_file=input_file, cuda_device=-1)
    
