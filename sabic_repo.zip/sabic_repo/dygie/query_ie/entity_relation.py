# -*- coding: utf-8 -*-
"""
Created on Sat Oct 17 17:32:27 2020

@author: SU20165358
"""



from typing import List, Iterator
import sys
import json

import os
#f = open(os.devnull, 'w')
#sys.stdout = f
#sys.stderr = f

import spacy
from allennlp.__main__ import run
from allennlp.common.checks import check_for_gpu, ConfigurationError
from allennlp.common.util import lazy_groups_of
from allennlp.models.archival import load_archive
from allennlp.predictors.predictor import Predictor
from allennlp.data import Instance

from allennlp.common.util import import_module_and_submodules
import_module_and_submodules('dygie')


### Entity Category search function
def entity_category_search(entity_span, sample_json):
    for ner_list in sample_json["predicted_ner"]:

        for ner in ner_list:
            ner_span = [ner[0], ner[1]]

            if ner_span == entity_span:
                entity_category = ner[2]

                return entity_category

### Coreference resolution function
def resolve_coreference(entity_span, sample_json):
    for cluster in sample_json["predicted_clusters"]:

        if cluster:

            if entity_span in cluster:
                entity_span = cluster[0]

                return entity_span

    else:

        return entity_span

### Triple Extraction function

def extract_triples(sample_json):
    import json
    sample_json = sample_json
    sample_json["predicted_clusters"] = []

    doc_key = sample_json["doc_key"]

    all_entity_list = []
    missed_entity_list = []

    coref_triple_list = []
    captured_entity_list = []

    sent_list = []

    for sentence in sample_json["sentences"]:
        sent_list += sentence

    # print(sent_list)

    for relation_list in sample_json["predicted_relations"]:

        if relation_list:

            for relation in relation_list:
                # print(relation)
                entity_1 = sent_list[relation[0]:relation[1] + 1]
                entity_1 = ' '.join(entity_1)
                entity_2 = sent_list[relation[2]:relation[3] + 1]
                entity_2 = ' '.join(entity_2)



                entity1_span = [relation[0], relation[1]]
                entity2_span = [relation[2], relation[3]]

                entity1_category = entity_category_search(entity1_span, sample_json)
                entity2_category = entity_category_search(entity2_span, sample_json)

                triple1 = entity1_category, entity_1
                triple2 = entity2_category, entity_2

                cap_1 = entity1_category, entity1_span
                cap_2 = entity2_category, entity2_span

                captured_entity_list.append(triple1)
                captured_entity_list.append(triple2)

                triple = triple1, relation[4], triple2

                # print("Normal triple :", triple)

                entity1_span_resolved = resolve_coreference(entity1_span, sample_json)

                entity2_span_resolved = resolve_coreference(entity2_span, sample_json)

                coref_e1 = sent_list[entity1_span_resolved[0]:entity1_span_resolved[1] + 1]
                coref_e1 = ' '.join(coref_e1)
                coref_e2 = sent_list[entity2_span_resolved[0]:entity2_span_resolved[1] + 1]
                coref_e2 = ' '.join(coref_e2)

                coref_triple1 = entity1_category, coref_e1
                coref_triple2 = entity2_category, coref_e2

                coref_triple = coref_triple1, relation[4], coref_triple2

                # print("Coreferenced triple :", coref_triple)

                coref_triple_list.append(coref_triple)

    for ner_list in sample_json["predicted_ner"]:

        for ner in ner_list:
            start_index = ner[0]
            end_index = ner[1]
            ner_span = [start_index, end_index]
            entity_category = entity_category_search(ner_span, sample_json)

            entity = sent_list[start_index:end_index + 1]
            entity = ' '.join(entity)
            # print(entity)
            actual_entity = entity_category, entity
            all_entity_list.append(actual_entity)

    for entity in all_entity_list:

        if entity not in captured_entity_list:
            missed_entity_list.append(entity)

    # print("-------------------")
    # print("All entities:", all_entity_list)
    # print("-------------------")
    # print("Missed entities:", missed_entity_list)
    # print("-------------------")

    # print("Coref_triple_list:", coref_triple_list)

    dygie_triple_json = {"doc_key": doc_key, "entity-relation-entity triples": coref_triple_list,
                         "missed_entities": missed_entity_list}

    # print("Dygie json:", dygie_triple_json)

    return dygie_triple_json



def generate_triples(dygie_jsonl):
    import json
    
    triples_lst = []
    for single_json in dygie_jsonl:
        # print(single_json)
        
        dygie_triples = extract_triples(single_json)
        dygie_triple_json = json.dumps(dygie_triples)
        triples_lst.append(dygie_triple_json)

    return(triples_lst)
########################################
def format_document(text, nlp):
    doc = nlp(text)
    sentences = [[tok.text for tok in sent] for sent in doc.sents]
    doc_key = 'a0'
    res = {"doc_key": doc_key,
           "sentences": sentences}
    return res
########################################

def _get_predictor(archive_file, cuda_device, weights_file, overrides, infer_predictor, dataset_reader_choice) -> Predictor:
    check_for_gpu(cuda_device)
    archive = load_archive(archive_file,
                           weights_file=weights_file,
                           cuda_device=cuda_device,
                           overrides=overrides)

    return Predictor.from_archive(archive, infer_predictor,
                                  dataset_reader_to_load=dataset_reader_choice)


class _PredictManager:

    def __init__(self,
                 predictor,
                 input_file,
                 batch_size,
                 print_to_console,
                 has_dataset_reader):

        self._predictor = predictor
        self._input_file = input_file
        self._batch_size = batch_size
        self._print_to_console = print_to_console
        if has_dataset_reader:
            self._dataset_reader = predictor._dataset_reader # pylint: disable=protected-access
        else:
            self._dataset_reader = None

    def _predict_instances(self, batch_data: List[Instance]) -> Iterator[str]:
        if len(batch_data) == 1:
            results = [self._predictor.predict_instance(batch_data[0])]
        else:
            results = self._predictor.predict_batch_instance(batch_data)
        for output in results:
            yield self._predictor.dump_line(output)


    def _get_instance_data(self) -> Iterator[Instance]:
        if self._input_file == "-":
            raise ConfigurationError("stdin is not an option when using a DatasetReader.")
        elif self._dataset_reader is None:
            raise ConfigurationError("To generate instances directly, pass a DatasetReader.")
        else:
            yield from self._dataset_reader.read(self._input_file)

    def run(self):
        has_reader = self._dataset_reader is not None
        op_lst = []
        if has_reader:
            for batch in lazy_groups_of(self._get_instance_data(), self._batch_size):
                #print(batch)
                for model_input_instance, result in zip(batch, self._predict_instances(batch)):
                    op_lst.append(json.loads(result))
                    
        else:
            pass
            
        return(op_lst)

nlp = spacy.load("en_core_web_sm")            
predictor = _get_predictor(archive_file='./pretrained/model.tar.gz', cuda_device=-1, weights_file=None, overrides='', infer_predictor='dygie', dataset_reader_choice='validation')
def predict_query(text, predictor=predictor, batch_size=1, silent=True, use_dataset_reader=True,nlp=nlp):
    
    input_file = [format_document(text, nlp)]
    #print(type(input_file[0]))
    manager = _PredictManager(predictor,
                              input_file,
                              batch_size,
                              silent,
                              use_dataset_reader)
    output = manager.run()
#    output = output[0]
    rdf = generate_triples(output)
    return json.loads(rdf[0])

