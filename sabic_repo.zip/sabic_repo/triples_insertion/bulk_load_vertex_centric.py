def vertex_edge_csv(file_path, parent_dict):
    vertex_lst = []
    edge_lst = []
    coauthor_weight = []
    with open(file_path, "r", encoding="utf-8") as file:
        for n, single_json in enumerate(file):
            #gc1, gc2, gc3, gc4, gc5 = '', '', '', '', ''
            single_json = json.loads(eval(single_json))
            
            doc_key = '_'.join(single_json["doc_key"].split('_')[0:-1])
            doc_url = single_json["url"]
            triples = single_json["entity-relation-entity triples"]
            triples = [i for i in triples if ((i[0][0] is not None) & (i[2][0] is not None))]
            triples = [i for i in triples if ((i[0][0] in parent_dict) & (i[2][0] in parent_dict))]
            missedTerms = single_json["missed_entities"]
            missedTerms = [i for i in missedTerms if i[0] is not None]
            missedTerms = [i for i in missedTerms if i[0] in parent_dict]
            
            if n==0:
                vertex_lst.append({'id':'Document_Generic'+'_4444_'+doc_key, 'classname':'Document_Generic', 'value':doc_key, 'iri':'http://www.sabic.com/SORKG#'+doc_key, 'doc_url':doc_url})
                edge_lst.append({'from':'Document_Generic'+'_4444_'+doc_key, 'to':parent_dict['Document_Generic']+'_4444_'+parent_dict['Document_Generic'], 'label':'rdfs:subClassOf'})
                
                authors = single_json["grobid_author"]
                authors_list = authors.split(' and ')
                if len(authors_list)>1:
                    #authors_list = authors_list
                    pass
                elif len(authors_list)==1:
                    if len(authors_list[0])<2:
                        authors_list = ['unknown']
                    else:
                        pass
                else:
                    authors_list = ['unknown']
                
                authors_list = [i.lower() for i in authors_list]
                for author in authors_list:
                    #author = author.lower()
                    classname = 'Author_Role'
                    vertex_lst.append({'id':classname+'_4444_'+author, 'classname':classname, 'value':author, 'iri':'http://www.sabic.com/SORKG#'+author})
                    edge_lst.append({'from':classname+'_4444_'+author, 'to':parent_dict[classname]+'_4444_'+parent_dict[classname], 'label':'rdfs:subClassOf'})
                    edge_lst.append({'from':classname+'_4444_'+author, 'to':'Document_Generic'+'_4444_'+doc_key, 'label':'rdfs:isAuthorOf'})
                    coauthor_weight.append({'document':doc_key, 'author':author})
            
                fset = set(frozenset(x) for x in itertools.product(authors_list, authors_list))
                coauthor_lst = [list(x) for x in fset]
                coauthor_lst = [i for i in coauthor_lst if len(i)==2]
                for co_auth in coauthor_lst:
                    classname = 'Author_Role'
                    edge_lst.append({'from':classname+'_4444_'+co_auth[0], 'to':classname+'_4444_'+co_auth[1], 'label':'rdfs:isCoAuthorOf'})

            for triple in triples:
                classname1 = triple[0][0]
                term1 = (triple[0][1]).lower()
                relation = triple[1]
                classname2 = triple[2][0]
                term2 = (triple[2][1]).lower()
                
                vertex_lst.append({'id':classname1+'_4444_'+term1, 'classname':classname1, 'value':term1, 'iri':'http://www.sabic.com/SORKG#'+term1})
                edge_lst.append({'from':classname1+'_4444_'+term1, 'to':parent_dict[classname1]+'_4444_'+parent_dict[classname1], 'label':'rdfs:subClassOf'})
                edge_lst.append({'from':classname1+'_4444_'+term1, 'to':'Document_Generic'+'_4444_'+doc_key, 'label':'isFoundIn'})
                
                vertex_lst.append({'id':classname2+'_4444_'+term2, 'classname':classname2, 'value':term2, 'iri':'http://www.sabic.com/SORKG#'+term2})
                edge_lst.append({'from':classname2+'_4444_'+term2, 'to':parent_dict[classname2]+'_4444_'+parent_dict[classname2], 'label':'rdfs:subClassOf'})
                edge_lst.append({'from':classname2+'_4444_'+term2, 'to':'Document_Generic'+'_4444_'+doc_key, 'label':'isFoundIn'})
                
                edge_lst.append({'from':classname1+'_4444_'+term1, 'to':classname2+'_4444_'+term2, 'label':relation})
                   
                
                
            for missed in missedTerms:
                classname = missed[0]
                term = (missed[1]).lower()
                vertex_lst.append({'id':classname+'_4444_'+term, 'classname':classname, 'value':term, 'iri':'http://www.sabic.com/SORKG#'+term})
                edge_lst.append({'from':classname+'_4444_'+term, 'to':parent_dict[classname]+'_4444_'+parent_dict[classname], 'label':'rdfs:subClassOf'})
                edge_lst.append({'from':classname+'_4444_'+term, 'to':'Document_Generic'+'_4444_'+doc_key, 'label':'isFoundIn'})
                
                
    return([vertex_lst, edge_lst, coauthor_weight])            
    

from glob import glob
import pandas as pd  
import json  
import itertools

##reading configuration settings
with open('./conf.txt', 'r') as f_conf:
    conf = f_conf.read()
conf_dict = json.loads(conf)  

kg_clean_build_path_local = conf_dict['kg_clean_build_path_local']
use_previous_parent_mapping = conf_dict['use_previous_parent_mapping']
gremlin_conn_url = conf_dict['gremlin_conn_url']
graph_name = conf_dict['graph_name'] + '_traversal'
classname_parent_dict_path = conf_dict['classname_parent_dict_path']
   
path = glob(kg_clean_build_path_local + '/*/*/*jsonl')

from gremlin_python.process.anonymous_traversal import traversal
from gremlin_python.process.traversal import T
from gremlin_python.driver.driver_remote_connection import DriverRemoteConnection
from tornado import httpclient
import numpy as np
#g = traversal().withRemote(DriverRemoteConnection(gremlin_conn_url, graph_name))
my_req = httpclient.HTTPRequest('wss://d02ycdpwrk002.sabic.com:8182/gremlin', ca_certs="/home/hadoop/artifacts/truststore.pem")
g = traversal().withRemote(DriverRemoteConnection(my_req,'UAT_A_traversal',username='baskaranj',password='Sabic@2020'))


## Getting vertex which is already available before bulk loading
graph_vertex_list_pre = g.V().valueMap(True).toList()
graph_vertex_df_pre = pd.DataFrame(graph_vertex_list_pre)
graph_vertex_df_pre.rename(columns={T.id:"id", T.label:"classname"}, inplace=True)
graph_vertex_df_pre = graph_vertex_df_pre[['id', 'classname', 'value']]
# print(graph_vertex_df_pre.columns)
# if 'url' in graph_vertex_df_pre.columns:
#     graph_vertex_df_pre.columns =  ['id', 'classname', 'iri', 'value', 'altValue', 'vClass','url']
# else:
#     graph_vertex_df_pre.columns = ['id', 'classname', 'iri', 'value', 'altValue']
distinct_classname = graph_vertex_df_pre['classname'].unique()
print(len(distinct_classname))
graph_vertex_df_pre['value'] = graph_vertex_df_pre['value'].apply(lambda x: x[0])
#graph_vertex_df_pre = graph_vertex_df_pre.drop_duplicates(subset=['classname','value'])
graph_vertex_df_pre['flag'] = 1

if use_previous_parent_mapping==0:
    print("Creating Parent mapping Json")
    parent_dict = {}
    for classname in distinct_classname:
        if g.V().has('vClass',classname).out("rdfs:subClassOf").hasNext():
            parent = g.V().has('vClass',classname).out("rdfs:subClassOf").values("vClass").next()
            parent_dict[classname] = parent

    with open(classname_parent_dict_path, 'w') as f:
        encoded = json.dumps(parent_dict)
        f.write(encoded)
else:
    with open(classname_parent_dict_path, 'r') as f:
        file = f.read()
        parent_dict = json.loads(file)


out = []
for i in path:
    out.append(vertex_edge_csv(i, parent_dict))

vertex_final = []
edge_final = []
coauthor_final = []
for k in out:
    vertex_final.extend(k[0])
    edge_final.extend(k[1])
    coauthor_final.extend(k[2])

vertex_df = pd.DataFrame(vertex_final)
vertex_df = pd.DataFrame.drop_duplicates(vertex_df)
edge_df = pd.DataFrame(edge_final)
edge_df = pd.DataFrame.drop_duplicates(edge_df)
edge_df['weight'] = -1 
coauthor_df = pd.DataFrame(coauthor_final)
coauthor_df = pd.DataFrame.drop_duplicates(coauthor_df)


# ##############co-author weight
# def weight(u,v):
#     return sum((u==1) & (v==1))

# def ert(a1, a2, score):
#     return score.loc[a1,a2]


# basket = coauthor_df.groupby(['document', 'author'])['author'] \
#           .count().unstack().reset_index().fillna(0) \
#           .set_index('document')
          
# tmp_2d = []
# for i in basket:
#     tmp_1d = []
#     for j in basket:
#         tmp_1d.append(weight(basket[i], basket[j]))
#     tmp_2d.append(tmp_1d)
    
# weight_score = pd.DataFrame(tmp_2d, columns = basket.columns, index = basket.columns)     

# # edge_df = pd.read_csv('C:/Users/singhsksuusm/sushil/edge.csv')
# edge_df1 = edge_df[edge_df['label'] != 'rdfs:isCoAuthorOf'] 
# edge_df1['weight'] = -1 
# edge_df2 = edge_df[edge_df['label'] == 'rdfs:isCoAuthorOf']
# # edge_df1 = edge_df[edge_df['label'] != 'rdfs:subClassOf']  
# # edge_df2 = edge_df[edge_df['label'] == 'rdfs:subClassOf']
# edge_df2['f1'] = edge_df2['from'].apply(lambda x: x[12:])
# edge_df2['t1'] = edge_df2['to'].apply(lambda x: x[12:])
# edge_df2['weight'] = edge_df2.apply(lambda x: ert(x['f1'], x['t1'], weight_score), axis=1)
# edge_df = pd.concat([edge_df1, edge_df2])
# edge_df.reset_index(drop=True, inplace=True)
# edge_df = edge_df[['from', 'to', 'label', 'weight']]
# ####################################
vertex_df.to_csv('./vertex.csv',index=None)
edge_df.to_csv('./edge.csv',index=None)

#vertex_df = pd.read_csv('./vertex.csv')
vertex_df = pd.merge(vertex_df, graph_vertex_df_pre[['classname','value','flag']], how = 'left', on = ['classname','value'])
vertex_df = vertex_df[vertex_df['flag'].isna()]
print("Adding Vertex.....................")
for n, row in vertex_df.iterrows():
    if row['classname']=='Document_Generic':
        g.addV(row['classname']) \
        .property('iri',row['iri']) \
        .property('url',row['doc_url']) \
        .property('value',row['value']) \
        .property('vClass',row['classname']) \
        .next()
    else:
        g.addV(row['classname']) \
        .property('iri',row['iri']) \
        .property('value',row['value']) \
        .property('vClass',row['classname']) \
        .next()

graph_vertex_list_post = g.V().valueMap(True).toList()
graph_vertex_df_post = pd.DataFrame(graph_vertex_list_post)
graph_vertex_df_post.rename(columns={T.id:"id", T.label:"classname"}, inplace=True)
graph_vertex_df_post = graph_vertex_df_post[['id', 'classname', 'value']]
# print(graph_vertex_df_post.columns)
# graph_vertex_df_post.columns = ['id', 'classname', 'iri', 'value', 'altValue', 'vClass','url']
graph_vertex_df_post['value'] = graph_vertex_df_post['value'].apply(lambda x: x[0])
graph_vertex_df_post['id_key'] = graph_vertex_df_post['classname']+'_4444_'+graph_vertex_df_post['value']
graph_vertex_df_post = graph_vertex_df_post.drop_duplicates(subset=['id_key'])

#edge_df = pd.read_csv('./edge.csv')
edge_df['entityCategory'] = edge_df['from'].apply(lambda x: x.split('_4444_')[0])
edge_final_df = pd.merge(edge_df, graph_vertex_df_post[['id_key','id']], how = 'left', left_on = 'from', right_on = 'id_key')
edge_final_df = edge_final_df[['id','to','label', 'weight', 'entityCategory']]
edge_final_df.columns = ['from', 'to', 'label', 'weight', 'entityCategory']

edge_final_df = pd.merge(edge_final_df, graph_vertex_df_post[['id_key','id']], how = 'left', left_on = 'to', right_on = 'id_key')
edge_final_df = edge_final_df[['from','id','label', 'weight', 'entityCategory']]
edge_final_df.columns = ['from', 'to', 'label', 'weight', 'entityCategory']

np.sum(edge_final_df.isna())
edge_final_df = edge_final_df.dropna()
for n, row in edge_final_df.iterrows():
    a = int(row['from'])
    b = row['label']
    c = int(row['to'])
    w = str(row['weight'])
    ec = row['entityCategory']
    g.addE(b).property('eClass', ec).from_(g.V(a)).to(g.V(c)).toList()
    print(n)


