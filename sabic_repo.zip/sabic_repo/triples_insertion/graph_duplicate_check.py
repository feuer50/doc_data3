   
    
from glob import glob
import pandas as pd  
import json  
import itertools

use_previous_parent_mapping = 1
local_path = './'

   
#path = glob('/data/01/sushil/kg_track/kg_insertion/KG_3models20201205/*/*/*jsonl')

from gremlin_python.process.anonymous_traversal import traversal
from gremlin_python.process.traversal import T
from gremlin_python.driver.driver_remote_connection import DriverRemoteConnection
import numpy as np
g = traversal().withRemote(DriverRemoteConnection('ws://d02ycdpwrk002:8182/gremlin', 'UAT-A1_traversal'))

## Getting vertex which is already available before bulk loading
graph_vertex_list_pre = g.V().valueMap(True).toList()
graph_vertex_df_pre = pd.DataFrame(graph_vertex_list_pre)
graph_vertex_df_pre.rename(columns={T.id:"id", T.label:"classname"}, inplace=True)
graph_vertex_df_pre = graph_vertex_df_pre[['id', 'classname', 'value']]
print('####################Before:')
print(graph_vertex_df_pre.shape)
# print(graph_vertex_df_pre.columns)
# if 'url' in graph_vertex_df_pre.columns:
#     graph_vertex_df_pre.columns =  ['id', 'classname', 'iri', 'value', 'altValue', 'vClass','url']
# else:
#     graph_vertex_df_pre.columns = ['id', 'classname', 'iri', 'value', 'altValue']
distinct_classname = graph_vertex_df_pre['classname'].unique()
graph_vertex_df_pre['value'] = graph_vertex_df_pre['value'].apply(lambda x: x[0])
graph_vertex_df_pre = graph_vertex_df_pre.drop_duplicates(subset=['classname','value'])
print('####################After:')
print(graph_vertex_df_pre.shape)

graph_vertex_df_pre['flag'] = 1



