# -*- coding: utf-8 -*-
"""
Created on Tue Sep 29 01:17:42 2020

@author: singhsksuusm
"""
import os
import json
import itertools
from datetime import datetime
import pyarrow as pa
from pyspark.sql import SparkSession
import numpy as np
import pandas as pd


spark = SparkSession.builder.getOrCreate()

def read_file_url(fs, file_path, mapping_json):
    from bs4 import BeautifulSoup as bs
    import bibtexparser
    try:
        #print(file_path)
        filename = '.'.join(file_path.split('/')[-1].split('.')[0:-1])
        original_filename = mapping_json[filename]
        hdfs_path = '/'.join(file_path.split('/')[0:-4]) + '/raw/' + file_path.split('/')[-3] + '/' + original_filename + '.urltxt'
        with fs.open(hdfs_path) as f:
            file = f.read()
        url = file.decode('utf-8')
        ####
        grobid_path = '/'.join(file_path.split('/')[0:-4]) + '/processed/' + file_path.split('/')[-3] + '/grobid/' + original_filename + '_Header.bib'
        if fs.exists(grobid_path):
            with fs.open(grobid_path) as bibtex_file:
                bibtex_database = bibtexparser.load(bibtex_file)
        
            header_op = bibtex_database.entries[0]   
            author_grobid = header_op['author']

        else:
            author_grobid = '0'
        ####
        tika_path = '/'.join(file_path.split('/')[0:-4]) + '/staging/' + file_path.split('/')[-3] + '/tika/' + original_filename + '.xml'
        with fs.open(tika_path) as f:
            content = f.read()
            #content = "".join(content)
            
        bs_content = bs(content, "lxml")
        paragraphs = bs_content.find_all("meta", attrs={'name':'Author'})
        authors = [i.attrs['content'] for i in paragraphs]
        if len(authors)>0:
            author_tika = authors[0]
        else:
            author_tika = '0'
        #author_tika = paragraphs[0].attrs['content']
        ####
        return([file_path, url, original_filename, author_grobid, author_tika])
    except:
        return(0)
    


def read_hdfs_file0(fs, hdfs_path):
    with fs.open(hdfs_path) as f:
        file = f.read()
    return file

def read_hdfs_file(fs, hdfs_path):
    lst = []
    with fs.open(hdfs_path, 'rb') as f:
        file = f.read()
    json_lines = '}$#|@{'.encode('utf-8').join(file.split('}\n{'.encode('utf-8'))).split('$#|@'.encode('utf-8'))
    if (len(json_lines)>1) or (len(json_lines[0])>0):
        for line in json_lines:
            single_json = json.loads(line)
            clean = pd.Series(str(single_json['sentences'][0])).str.replace(r'\s+', ' ')[0]
            clean = pd.Series(clean).str.replace(r'[\d\s\.,?\-%\+E]{64,}', '')[0]
            if clean:
                lst.append(clean)
        if (hdfs_path.endswith('pdf.json') | hdfs_path.endswith('doc.json') | hdfs_path.endswith('docx.json') | hdfs_path.endswith('ppt.json') | hdfs_path.endswith('pptx.json')):
            i1=0
            i2=5
            no_lines = int(np.ceil((len(lst)/5))) 
            paragraph = []       
            for i in range(no_lines):
                m = ' '.join(lst[i1:i2])
                if m:
                    paragraph.append(m)
                i1 = i2
                i2 = i2+5
            return paragraph
        else:
            return lst
    else:
        return(['Empty File'])
            

    
def write_to_hdfs(fs, src1, src2, xml_file, original_filename, model_n, kg_folder):
    '''
    Parameters
    ----------
    fs : pyarrow hdfs client
    src1 : python object containing DyGIE++ output
    src2: python object containing triples output
    xml_file: hdfs path of input xml file
    output_path1: DyGIE++ output hdfs path
    output_path2: triples output hdfs path
    '''
    
    #output_path1    
    if fs.exists('/'.join(xml_file.split('/')[0:-2]) + '/dygie_op/'):
        output_path1 = '/'.join(xml_file.split('/')[0:-2]) + '/dygie_op/'
    else:
        fs.mkdir('/'.join(xml_file.split('/')[0:-2]) + '/dygie_op/')
        output_path1 = '/'.join(xml_file.split('/')[0:-2]) + '/dygie_op/'
    
    #output_path2
    #if fs.exists(kg_folder + xml_file.split("/")[-3] + '/' + '.'.join(xml_file.split("/")[-1].split(".")[0:-2]) + '_' + xml_file.split("/")[-1].split(".")[-2]):
    #    output_path2 = kg_folder  + xml_file.split("/")[-3] + '/' + '.'.join(xml_file.split("/")[-1].split(".")[0:-2]) + '_' + xml_file.split("/")[-1].split(".")[-2] + '/'
    #else:
    #    fs.mkdir(kg_folder  + xml_file.split("/")[-3] + '/' + '.'.join(xml_file.split("/")[-1].split(".")[0:-2]) + '_' + xml_file.split("/")[-1].split(".")[-2])
    #    output_path2 = kg_folder  + xml_file.split("/")[-3] + '/' + '.'.join(xml_file.split("/")[-1].split(".")[0:-2]) + '_' + xml_file.split("/")[-1].split(".")[-2] + '/'
    
    
    #output_path2
    if fs.exists(kg_folder + xml_file.split("/")[-3] + '/' + '.'.join(original_filename.split(".")[0:-1]) + '_' + original_filename.split(".")[-1]):
        output_path2 = kg_folder  + xml_file.split("/")[-3] + '/' + '.'.join(original_filename.split(".")[0:-1]) + '_' + original_filename.split(".")[-1] + '/'
    else:
        fs.mkdir(kg_folder  + xml_file.split("/")[-3] + '/' + '.'.join(original_filename.split(".")[0:-1]) + '_' + original_filename.split(".")[-1])
        output_path2 = kg_folder  + xml_file.split("/")[-3] + '/' + '.'.join(original_filename.split(".")[0:-1]) + '_' + original_filename.split(".")[-1] + '/'
        
    dst1 = output_path1 + original_filename + '_dygieop' + str(model_n) + '.jsonl'    
    if not fs.exists(dst1):
        with fs.open(dst1,'wb') as hfs1:
            for s1 in src1:
                hfs1.write(json.dumps(s1).encode('utf-8'))
                hfs1.write('\n'.encode('utf-8'))
    else:
        fs.delete(dst1)
        with fs.open(dst1,'wb') as hfs1:
            for s1 in src1:
                hfs1.write(json.dumps(s1).encode('utf-8'))
                hfs1.write('\n'.encode('utf-8'))
    
    dst2 = output_path2 + original_filename + '_triple' + str(model_n) + '.jsonl'        
    if not fs.exists(dst2):
        with fs.open(dst2,'wb') as hfs2:
            for s2 in src2:
                hfs2.write(json.dumps(s2).encode('utf-8'))
                hfs2.write('\n'.encode('utf-8'))
    else:
        fs.delete(dst2)
        with fs.open(dst2,'wb') as hfs2:
            for s2 in src2:
                hfs2.write(json.dumps(s2).encode('utf-8'))
                hfs2.write('\n'.encode('utf-8'))

        
       
        
### Entity Category search function
def entity_category_search(entity_span, sample_json):
    for ner_list in sample_json["predicted_ner"]:

        for ner in ner_list:
            ner_span = [ner[0], ner[1]]

            if ner_span == entity_span:
                entity_category = ner[2]

                return entity_category

### Coreference resolution function
def resolve_coreference(entity_span, sample_json):
    for cluster in sample_json["predicted_clusters"]:

        if cluster:

            if entity_span in cluster:
                entity_span = cluster[0]

                return entity_span

    else:

        return entity_span

### Triple Extraction function

def extract_triples(sample_json):
    import json
    
    sample_json["predicted_clusters"] = []
    doc_key = sample_json["doc_key"]

    all_entity_list = []
    missed_entity_list = []

    coref_triple_list = []
    captured_entity_list = []

    sent_list = []

    for sentence in sample_json["sentences"]:
        sent_list += sentence

    # print(sent_list)

    for relation_list in sample_json["predicted_relations"]:

        if relation_list:

            for relation in relation_list:
                # print(relation)
                entity_1 = sent_list[relation[0]:relation[1] + 1]
                entity_1 = ' '.join(entity_1)
                entity_2 = sent_list[relation[2]:relation[3] + 1]
                entity_2 = ' '.join(entity_2)

                print("-----------------------")

                entity1_span = [relation[0], relation[1]]
                entity2_span = [relation[2], relation[3]]

                entity1_category = entity_category_search(entity1_span, sample_json)
                entity2_category = entity_category_search(entity2_span, sample_json)

                triple1 = entity1_category, entity_1
                triple2 = entity2_category, entity_2

                cap_1 = entity1_category, entity1_span
                cap_2 = entity2_category, entity2_span

                captured_entity_list.append(triple1)
                captured_entity_list.append(triple2)

                triple = triple1, relation[4], triple2

                # print("Normal triple :", triple)

                entity1_span_resolved = resolve_coreference(entity1_span, sample_json)

                entity2_span_resolved = resolve_coreference(entity2_span, sample_json)

                coref_e1 = sent_list[entity1_span_resolved[0]:entity1_span_resolved[1] + 1]
                coref_e1 = ' '.join(coref_e1)
                coref_e2 = sent_list[entity2_span_resolved[0]:entity2_span_resolved[1] + 1]
                coref_e2 = ' '.join(coref_e2)

                coref_triple1 = entity1_category, coref_e1
                coref_triple2 = entity2_category, coref_e2

                coref_triple = coref_triple1, relation[4], coref_triple2

                # print("Coreferenced triple :", coref_triple)

                coref_triple_list.append(coref_triple)

    for ner_list in sample_json["predicted_ner"]:

        for ner in ner_list:
            start_index = ner[0]
            end_index = ner[1]
            ner_span = [start_index, end_index]
            entity_category = entity_category_search(ner_span, sample_json)

            entity = sent_list[start_index:end_index + 1]
            entity = ' '.join(entity)
            # print(entity)
            actual_entity = entity_category, entity
            all_entity_list.append(actual_entity)

    for entity in all_entity_list:

        if entity not in captured_entity_list:
            missed_entity_list.append(entity)

    # print("-------------------")
    # print("All entities:", all_entity_list)
    # print("-------------------")
    # print("Missed entities:", missed_entity_list)
    # print("-------------------")

    # print("Coref_triple_list:", coref_triple_list)

    dygie_triple_json = {"doc_key": doc_key, "entity-relation-entity triples": coref_triple_list,
                         "missed_entities": missed_entity_list}

    # print("Dygie json:", dygie_triple_json)

    return dygie_triple_json



def generate_triples(dygie_jsonl, url, grobid_author, tika_author):
    import json
    
    triples_lst = []
    for single_json in dygie_jsonl:
        # print(single_json)
        print("-----------------------------")
        
        dygie_triples = extract_triples(single_json)
        dygie_triples['url'] = url
        dygie_triples['grobid_author'] = grobid_author
        dygie_triples['tika_author'] = tika_author
        dygie_triple_json = json.dumps(dygie_triples)
        triples_lst.append(dygie_triple_json)

    return(triples_lst)



def format_document(text, nlp, n, prefix_dockey):
    doc = nlp(text)
    sentences = [[tok.text for tok in sent] for sent in doc.sents]
    doc_key = prefix_dockey + '_' + str(n)
    res = {"doc_key": doc_key,
           "sentences": sentences}
    return res


def process_document(file_list, model_folder, use_scispacy=False):
    
    import os
    os.environ["HOME"] = '/tmp'
    import sys
    import json
    from bs4 import BeautifulSoup as bs
    import spacy
    from dygie.pyspark_dygie import pyspark_dygie_predict
    from dygie.data.dataset_readers import collate1
    from glob import glob
    
    try:
        model_paths = glob(model_folder + "*tar.gz")
        print(model_paths)
        nlp_name = "en_core_sci_sm" if use_scispacy else "en_core_web_sm"
        nlp = spacy.load(nlp_name)
        
        #prefix_dockey = '_'.join(file_list[0].split('/')[-3:])[0:-4] 
        prefix_dockey = file_list[0].split('/')[-3] + '_' + file_list[3]  
        texts = file_list[1]
        res = [format_document(text, nlp, n, prefix_dockey) for n, text in enumerate(texts)]
        #res = [i for i in res if (len(i["sentences"])>1 or len(i["sentences"][0])>1)]
        
        res = collate1.main(res)
        for i in res:
            i['doc_key'] = prefix_dockey + '_' + str(i['doc_key'])
        if res:
            files_to_write = []
            for model_path in model_paths:
                n = model_path.split('/')[-1].split('.')[0].split('_')[-1]
                dygie_op = pyspark_dygie_predict.predict_spark(archive_file=model_path, input_file=res, cuda_device=-1)
            
                rdf = generate_triples(dygie_op, file_list[2], file_list[4], file_list[5])
                files_to_write.append([dygie_op, rdf, file_list[0], file_list[3], n])
            return(files_to_write)
        
        else:
            return([['dygie_op', 'rdf', file_list[0], file_list[3], -1]])
    except:
        return([['dygie_op', 'rdf', file_list[0], file_list[3], -1]])    
        

##reading configuration settings
with open('./conf.txt', 'r') as f_conf:
    conf = f_conf.read()
conf_dict = json.loads(conf)  
          
model_folder = conf_dict['model_folder']
kg_folder = conf_dict['kg_folder']
ks_base = conf_dict['ks_base']
ks_folder1 = conf_dict['ks_folder1']
ks_folder2 = conf_dict['ks_folder2']
ecm_mapping_path = conf_dict['ecm_mapping_path']
kmp_mapping_path = conf_dict['kmp_mapping_path']
eln_mapping_path = conf_dict['eln_mapping_path']

pyarrow_libhdfs = conf_dict['arrow_libhdfs_dir']
os.environ['ARROW_LIBHDFS_DIR'] = pyarrow_libhdfs
fs = pa.hdfs.connect()

if conf_dict['process_for_today'] == 'yes':
    now = datetime.now()
    dates = [now.strftime("%Y%m%d")]
else:
    dates = conf_dict['dates']
    
sources = conf_dict['data_sources']

input_xml_folders = [ks_base + i[0] + ks_folder1 + i[1] + ks_folder2 for i in itertools.product(dates,sources)]
input_xml_folders = [i for i in input_xml_folders if fs.exists(i)]

file_path = []
for input_xml_folder in input_xml_folders: 
    tmp_file_path = fs.ls(input_xml_folder)
    
    if 'ecm' in input_xml_folder.split('/'):
        mapping_path = ecm_mapping_path
    elif 'kmp' in input_xml_folder.split('/'):
        mapping_path = kmp_mapping_path
    elif 'eln' in input_xml_folder.split('/'):
        mapping_path = eln_mapping_path
    else:
        pass
    
    #mapping_path = '/projects/source/AIKM/ks/ecm_mapping.json'
    with fs.open(mapping_path) as fmap:
        path_map = fmap.read()
    mapping_json = json.loads(path_map)
    mapping_json = {'.'.join(k.split('.')[0:-1]):'.'.join(v.split('.')[0:-1]) for k,v in mapping_json.items()}
    
    tmp_file_path = [i for i in tmp_file_path if i.endswith('.json')]
    tmp_file_path = [i for i in tmp_file_path if i.endswith(('pdf.json', 'PDF.json', 'pptx.json', 'ppt.json', 'docx.json', 'doc.json', 'DOC.json', 'xlsx.json', 'xls.json'))]
    #tmp_file_path = [i for i in tmp_file_path if i.endswith(('PDF.json', 'DOC.json', 'xls.json',  'ppt.json'))]
    #tmp_file_path = [i for i in tmp_file_path if i.endswith('pdf.json')]
    tmp_file_path = [i for i in tmp_file_path if '.'.join(i.split('/')[-1].split('.')[0:-1]) in mapping_json]
    #tmp_file_path = tmp_file_path[0:2]
    tmp_file_path = [read_file_url(fs, i, mapping_json) for i in  tmp_file_path]
    tmp_file_path = [i for i in tmp_file_path if i!=0]
    file_path.extend(tmp_file_path)
   
if len(file_path)>0:
    file_path_content = [[i[0], read_hdfs_file(fs,i[0]), i[1], i[2], i[3], i[4]] for i in file_path]
    file_path_content = [i for i in file_path_content if i[1] != ['Empty File']]
    print(len(file_path_content))
    path_content_rdd = spark.sparkContext.parallelize(file_path_content)
    
    out = path_content_rdd.map(lambda x: process_document(x, model_folder)).collect()
    #out = [process_document(x, model_folder) for x in file_path_content]
    
    #out1 = [write_to_hdfs(fs, i[0], i[1], i[2], i[3], kg_folder) for i in out if i[1]!='rdf']
    out1 = [write_to_hdfs(fs, i[0], i[1], i[2], i[3], i[4], kg_folder) for f in out for i in f if i[1]!='rdf']
     
else:
    print('**********No JSON file found in input(Fonduer) folder*******************')
    
