def get_resource(id):
    resource=id[:3]
    fileName=id[4:]
    return resource,fileName

def getDirName(filename):
    index=filename.rfind('.')
    dirName=filename[:index]+'_'+filename[index+1:]
    return dirName

def getFileNames(resource,dirname):
    import pyarrow as pa
    import os
    os.environ['ARROW_LIBHDFS_DIR']='/opt/cloudera/parcels/CDH/lib64/'
    fs = pa.hdfs.connect()
    if get_ext(dirname) != 'pdf':
        dir_in = f'/projects/source/AIKM/ks/NON_PDF_IMAGE_BLOB_STORE/{resource}/{dirname}'
    else:
        dir_in = f'/projects/source/AIKM/ks/IMAGE_BLOB_STORE/{resource}/{dirname}'
    #print(dir_in)
    all_dart_dirs = fs.ls(dir_in)
    #print('****************************************************')
    #print(all_dart_dirs)
    return all_dart_dirs


def getImage(filename):
    import subprocess
    temp=filename.strip()
    args = f"hdfs dfs -get '{temp}'"
    #print(f"In get image{args}")
    proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    s_output, s_err = proc.communicate()


def pathTofile(path):
    if type(path)==str:
        index = path.rfind('/')
    else:
        index = path.decode('utf-8').rfind('/')
    img_path = path[:index]
    img_filename =path[index + 1:]
    return img_path,img_filename

def delete_img(img_file_name):
    import os
    os.remove(img_file_name.strip())

def mapFilePath(lst):
    paths=[]
    for path in lst:
        if '/projects/source/AIKM/ks/' in str(path):
            if 'json' not in str(path):
                paths.append(path)
    return paths

def encode_to_base(imgName):
    import base64
    #imgName = f"'{imgName.strip()}'"
    with open(imgName.strip(),"rb") as imgFile:
        encoded_string=base64.b64encode(imgFile.read())
    return encoded_string
    
def get_ext(path):
    index = path.rfind('_')
    ext =path[index + 1:]
    #print(f'extension is {ext}')
    return ext
