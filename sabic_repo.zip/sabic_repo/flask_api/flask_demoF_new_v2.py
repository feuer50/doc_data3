from flask import Flask, request, redirect, url_for, flash, jsonify
from dygie.query_ie import entity_relation
import pandas as pd
import numpy as np
from functools import reduce
import json

from gremlin_python.process.anonymous_traversal import traversal
from gremlin_python.process.traversal import T
from gremlin_python.process.traversal import TextP
from gremlin_python.process.graph_traversal import __
from gremlin_python.driver.driver_remote_connection import DriverRemoteConnection
g = traversal().withRemote(DriverRemoteConnection('ws://d02ycdpwrk002:8182/gremlin', 'DEMO_newD_traversal'))

import pathlib
from rasa.cli.utils import get_validated_path
from rasa.model import get_model, get_model_subdirectories
from rasa.nlu.model import Interpreter
from rasa.shared.nlu.training_data.message import Message
from rasa.shared.nlu.constants import TEXT

app = Flask(__name__)

def load_interpreter(model_path):
    """
    This loads the Rasa NLU interpreter. It is able to apply all NLU
    pipeline steps to a text that you provide it.
    """
    model = get_validated_path(model_path, "model")
    model_path = get_model(model)
    _, nlu_model = get_model_subdirectories(model_path)
    return Interpreter.load(nlu_model)

nlu_interpreter = load_interpreter("models/nlu-20210107-153747.tar.gz")


with open('./pagerank_recommendation_i1.json') as f:
    pagerank_json = json.load(f)

  
# def search_recommendation(entity_list):
#     recommend = []
#     for e in entity_list:
#         if e[0] in pagerank_json.keys():
#             recommend.extend(pagerank_json[e[0]])
#     return recommend

def search_recommendation(entity_list):
    recommend = {}
    for e in entity_list:
        if e[0] in pagerank_json.keys():
            recommend.update({e[0]:pagerank_json[e[0]]})
    return recommend

# def search_recommendation1(entity_list):
#     try:
#         r_entity = entity_list[0][1]
#         r_class = entity_list[0][0]
#         if r_class=='Author_Role':
#             q1 = g.V().has('value', r_entity).out('rdfs:isAuthorOf').dedup().path().by(__.valueMap(True)).toList()
#             q2 = g.V().has('vClass', r_class).out('rdfs:isAuthorOf').dedup().path().by(__.valueMap(True)).toList()
#         else:
#             q1 = g.V().has('value', r_entity).out('rdfs:isFoundIn').dedup().path().by(__.valueMap(True)).toList()
#             q2 = g.V().has('vClass', r_class).out('rdfs:isFoundIn').dedup().path().by(__.valueMap(True)).toList()
    
#         lst1 = []
#         for i in q1:
#             df_dict1 = {}
#             df_dict1['entity'] = i[0]['value'][0]
#             df_dict1['doc_vertex_id'] = i[1][T.id]
#             df_dict1['doc_url'] = i[1]['url'][0]
            
#             lst1.append(df_dict1)
            
#         df1 = pd.DataFrame(lst1)
        
        
#         lst2 = []
#         for i in q2:
#             df_dict2 = {}
#             df_dict2['accolade_id'] = i[0]['value'][0]
#             df_dict2['doc_vertex_id'] = i[1][T.id]
#             #df_dict2['doc_url'] = i[1]['url'][0]
            
#             lst2.append(df_dict2)
            
#         df2 = pd.DataFrame(lst2)
#         if (len(df1)>0) & (len(df2)>0):
#             merged_df = pd.merge(df1, df2, on = 'doc_vertex_id')
#             if len(merged_df)>0:
#                 recommend = [[n,len(i)] for n,i in merged_df.groupby('accolade_id')]
#                 recommend = sorted(recommend, key = lambda x: -x[1])
#                 recommend = [i[0] for i in recommend]
#                 recommend = [i for i in recommend if i not in ['unknown', r_entity]]
#                 recommend = [i for n,i in enumerate(recommend) if n<5]
#                 recommend1 = {r_class:recommend}
#             else:
#                 recommend1 = {}
#         else:
#             recommend1 = {}
#     except:
#         recommend1 = {}
            
#     return recommend1
    
def search_recommendation1(entity_list):
    try:
        r_entity = entity_list[0][1]
        r_class = entity_list[0][0]
        if r_class=='Author_Role':
            q1 = g.V().has('value', r_entity).out('rdfs:isAuthorOf').dedup().path().by(__.valueMap(True)).toList()
            q2 = g.V().has('vClass', r_class).out('rdfs:isAuthorOf').dedup().path().by(__.valueMap(True)).toList()
        else:
            q1 = g.V().has('value', r_entity).out('rdfs:isFoundIn').dedup().path().by(__.valueMap(True)).toList()
            q2 = g.V().has('vClass', r_class).out('rdfs:isFoundIn').dedup().path().by(__.valueMap(True)).toList()
    
        lst1 = []
        for i in q1:
            df_dict1 = {}
            df_dict1['entity'] = i[0]['value'][0]
            df_dict1['doc_vertex_id'] = i[1][T.id]
            df_dict1['doc_url'] = i[1]['url'][0]
            
            lst1.append(df_dict1)
            
        df1 = pd.DataFrame(lst1)
        
        
        lst2 = []
        for i in q2:
            df_dict2 = {}
            df_dict2['accolade_id'] = i[0]['value'][0]
            df_dict2['doc_vertex_id'] = i[1][T.id]
            #df_dict2['doc_url'] = i[1]['url'][0]
            
            lst2.append(df_dict2)
            
        df2 = pd.DataFrame(lst2)
        if (len(df1)>0) & (len(df2)>0):
            merged_df = pd.merge(df1, df2, on = 'doc_vertex_id')
            if len(merged_df)>0:
                recommend = [[n,len(i)] for n,i in merged_df.groupby('accolade_id')]
                recommend = sorted(recommend, key = lambda x: -x[1])
                recommend = [i[0] for i in recommend]
                recommend = [i for i in recommend if i not in ['unknown','-', r_entity]]
                recommend = [i for i in recommend if len(i.strip())>1]
                recommend = [i for n,i in enumerate(recommend) if n<5]
                recommend1 = recommend
            else:
                recommend1 = []
        else:
            recommend1 = []
    except:
        recommend1 = []
            
    return recommend1

    

def chemical_property(entity_list):
    if entity_list:
        entity_list = [i for i in entity_list if i[0] == 'Chemical_Entity']
        entity_list = [i[1] for i in entity_list if len(i[1].strip())>1]
        entity_list = list(set(entity_list))
        #entity_list = ['methane', 'butane', 'sodium']
        prop = [[i, g.V().has('Chemical_Entity' ,'value', i).valueMap(True).toList()] for i in entity_list]
        
        prop_lst = []
        for p in prop:
            if p[1]:
                b = {k:v[0] for k,v in p[1][0].items() if k not in [T.id, T.label, 'iri', 'vClass', 'value']} 
                b['prop_synonyms'] = b['prop_other_names']
                b = {k:v for k,v in b.items() if v!= 'Unavailable'} 
                prop_lst.append([p[0], b])    
            else:
                pass
    else:
        prop_lst = []
    return prop_lst
    
    

def janusG(term):
    
    #a = g.V().has('value', term).values('prop_synonyms', 'prop_preferred_names').toList()
    a = g.V().has('value', term).values('prop_other_names', 'prop_preferred_names').toList()
    # a = [j for sub in a for j in eval(sub)]
    
    if a:
        a = [i.split('; ') for i in a]
        a = [j for i in a for j in i]
        a.append(term)
        b = list(set(a))
        output = {'altValue': b, 'synonyms': {term: b}, 'information':['Chemical_Entity', term]}
    else:
        output = {'altValue': [], 'synonyms': {}, 'information':[]}
    return output

def dygie_janusG(text, category_entity):
    term_list = category_entity
    #term_list = [i for i in term_list if i[0] == 'Chemical_Entity']
    if term_list:
        lst = []
        syn = {}
        for term in term_list:
            term = term[1]
            #a = g.V().has('value', term).values('prop_synonyms', 'prop_preferred_names').toList()
            a = g.V().has('value', term).values('prop_other_names', 'prop_preferred_names').toList()
            # a = [j for sub in a for j in eval(sub)]
            if a:
                a = [i.split('; ') for i in a]
                a = [j for i in a for j in i]
                a.append(term)
                b = list(set(a))
                lst.extend(b)
                syn.update({term: b})
        if lst:
            lst = list(set(lst))
            output = {'altValue': lst, 'synonyms':syn}
        else:
            output = {'altValue': [], 'synonyms': {}}

    else:
        output = {'altValue': [], 'synonyms': {}}

    return output



def find_abbreviation(text, r_intent, r_classname, r_entity):

    if r_classname == 'Abbreviation':
        s = g.V().has('Abbreviation','value',r_entity).out('abbreviationExplainedBy').values('value').toList()
        if s:
            abb = {'abbreviation':{r_entity:[s[0]]}}
        else:
            abb = {'abbreviation':{}}
    else:
        abb = {'abbreviation':{}}
    return abb

def author():
    s = g.V().hasLabel('Author_Role').both()

# def accoladeID(text):
#     entity = text
#     a = g.V().has('value', entity).out('rdfs:isFoundIn').in_().hasLabel('Accolade_ID').dedup().out('rdfs:isFoundIn').path().by(__.valueMap()).toList()    
#     lst =[]    
#     for i in a:
#         df_dict = {}
#         df_dict['entity'] = i[0]['value'][0]
#         df_dict['entity_doc'] = '_'.join(i[1]['value'][0].split('_')[1:])
#         df_dict['entity_url'] = i[1]['url'][0]
#         df_dict['accolade_id'] = i[2]['value'][0]
#         df_dict['accolade_doc'] = '_'.join(i[3]['value'][0].split('_')[1:])
#         df_dict['accolade_url'] = i[3]['url'][0]
#         df_dict['accolade_doc_url'] = ['_'.join(i[3]['value'][0].split('_')[1:]) , i[3]['url'][0]]
#         lst.append(df_dict)
        
#     df = pd.DataFrame(lst)
        
#     accolade_op = {n:list(i['accolade_doc_url']) for n,i in df.groupby('accolade_id')}
#     return accolade_op

# def accoladeID_sen(text, r_inference, dygie_op):
#     r_classname = r_inference['entities'][0]['entity']
#     r_entity = r_inference['entities'][0]['value']

#     triples = dygie_op["entity-relation-entity triples"]
#     missedTerms = dygie_op["missed_entities"]
#     if len(r_entity)>0:
#         missedTerms.append([r_classname, r_entity])
#     for i in triples:
#         missedTerms.append(i[0])
#         missedTerms.append(i[2])
    
#     accolade_op = {}
#     for e in missedTerms:
    
#         entity = e[1]
#         a = g.V().has('value', entity).out('rdfs:isFoundIn').in_().hasLabel('Accolade_ID').dedup().out('rdfs:isFoundIn').path().by(__.valueMap()).toList()
#         lst =[]
#         for i in a:
#             df_dict = {}
#             df_dict['entity'] = i[0]['value'][0]
#             df_dict['entity_doc'] = '_'.join(i[1]['value'][0].split('_')[1:])
#             df_dict['entity_url'] = i[1]['url'][0]
#             df_dict['accolade_id'] = i[2]['value'][0]
#             df_dict['accolade_doc'] = '_'.join(i[3]['value'][0].split('_')[1:])
#             df_dict['accolade_url'] = i[3]['url'][0]
#             df_dict['accolade_doc_url'] = ['_'.join(i[3]['value'][0].split('_')[1:]) , i[3]['url'][0]]
#             lst.append(df_dict)
        
#         if len(lst)>0:
#             df = pd.DataFrame(lst)
    
#             acc_temp = {n:list(i['accolade_doc_url']) for n,i in df.groupby('accolade_id')}
#         else:
#             acc_temp = {}
#         accolade_op.update(acc_temp)
#     return accolade_op

# def extract_url(category_entity):
#     lst = []
#     for i in category_entity:
#         s = g.V().has('value', i[1]).out('rdfs:isFoundIn').values('url').toList()
#         lst.append(s)
#     return(lst)

def extract_url(entity_list):
    entity_list = [i[1] for i in entity_list if len(i[1].strip())>1]
    entity_list = list(set(entity_list))
    #entity_list = ['methane', 'butane', 'sodium']
    query = [g.V().has('value', i).out('rdfs:isFoundIn').dedup().path().by(__.valueMap(True)).toList() for i in entity_list]
    
    m_lst = []
    for q in query:
        t_lst = []
        for i in q:
            tdf_dict = {}
            #tdf_dict['entity'] = i[0]['value'][0]
            tdf_dict['doc_vertex_id'] = i[1][T.id]
            tdf_dict['doc_url'] = i[1]['url'][0]
            
            t_lst.append(tdf_dict)
            
        m_lst.append(pd.DataFrame(t_lst))
    if m_lst:        
        df_merged = reduce(lambda  left,right: pd.merge(left,right,on=['doc_vertex_id', 'doc_url'],how='inner'), m_lst)
    else:
        df_merged = pd.DataFrame()
    return df_merged

def accolade1(df1):
    # q1 = g.V().has('value', r_entity).out('rdfs:isFoundIn').dedup().path().by(__.valueMap(True)).toList()
    q2 = g.V().has('vClass', 'Accolade_ID').out('rdfs:isFoundIn').dedup().path().by(__.valueMap(True)).toList()

    # lst1 = []
    # for i in q1:
    #     df_dict1 = {}
    #     df_dict1['entity'] = i[0]['value'][0]
    #     df_dict1['doc_vertex_id'] = i[1][T.id]
    #     df_dict1['doc_url'] = i[1]['url'][0]
        
    #     lst1.append(df_dict1)
        
    # df1 = pd.DataFrame(lst1)
    
    
    lst2 = []
    for i in q2:
        df_dict2 = {}
        df_dict2['accolade_id'] = i[0]['value'][0]
        df_dict2['doc_vertex_id'] = i[1][T.id]
        #df_dict2['doc_url'] = i[1]['url'][0]
        
        lst2.append(df_dict2)
        
    df2 = pd.DataFrame(lst2)
    if (len(df1)>0) & (len(df2)>0):
        merged_df = pd.merge(df1, df2, on = 'doc_vertex_id')
        if len(merged_df)>0:
            accolade_op = [[n, len(i), list(i['doc_url']), accolade_property(n)] for n,i in merged_df.groupby('accolade_id')]
        else:
            accolade_op = []
    else:
        accolade_op = []
        
    return accolade_op


def accolade(r_entity):
    q1 = g.V().has('value', r_entity).out('rdfs:isFoundIn').dedup().path().by(__.valueMap(True)).toList()
    q2 = g.V().has('vClass', 'Accolade_ID').out('rdfs:isFoundIn').dedup().path().by(__.valueMap(True)).toList()

    lst1 = []
    for i in q1:
        df_dict1 = {}
        df_dict1['entity'] = i[0]['value'][0]
        df_dict1['doc_vertex_id'] = i[1][T.id]
        df_dict1['doc_url'] = i[1]['url'][0]
        
        lst1.append(df_dict1)
        
    df1 = pd.DataFrame(lst1)
    
    
    lst2 = []
    for i in q2:
        df_dict2 = {}
        df_dict2['accolade_id'] = i[0]['value'][0]
        df_dict2['doc_vertex_id'] = i[1][T.id]
        #df_dict2['doc_url'] = i[1]['url'][0]
        
        lst2.append(df_dict2)
        
    df2 = pd.DataFrame(lst2)
    if (len(df1)>0) & (len(df2)>0):
        merged_df = pd.merge(df1, df2, on = 'doc_vertex_id')
        if len(merged_df)>0:
            accolade_op = [[n,len(i),list(i['doc_url']), accolade_property(n)] for n,i in merged_df.groupby('accolade_id')]
        else:
            accolade_op = []
    else:
        accolade_op = []
        
    return accolade_op

def accolade_property(acc_id):
    a = g.V().has('Accolade_ID' ,'value', acc_id).valueMap(True).toList()
    a = a[0]
    if len(a)==0:
        a = {}
    else: 
        pass
    if 'projectName' in a.keys():
        acc_prop = {k:v[0] for k,v in a.items() if k in ['projectUrl', 'projectCreationDate', 'projectDescription', 'projectCurrentStageName', 'projectLeaderName', 'projectName']}
        acc_prop['AccoladeID'] = acc_id
    else:
        acc_prop = {'AccoladeID': acc_id, 'projectUrl': 'not available', 'projectCreationDate': 'not available', 'projectDescription': 'not available', 'projectCurrentStageName': 'not available', 'projectLeaderName': 'not available', 'projectName': 'not available'}
    return acc_prop

# def solr_q(query_ip):
#     entity_list = query_ip['information']
#     s_list = query_ip['abbreviation']
#     s_list1 = list(s_list.values())
#     if s_list1:
#         semantic_list = s_list1[0]
#     else:
#         semantic_list = []
#     synonym_list = query_ip['altValue']
#     solr_entity = [i[1] for i in entity_list if len(i[1].strip())>1]
#     solr_entity = list(set(solr_entity))
#     solr_entity = ['"{}"'.format(i) for i in solr_entity]
#     ' AND '.join(solr_entity)
    
#     semantic_list = ['"{}"'.format(i) for i in semantic_list]
#     ' OR '.join(semantic_list)
    
#     synonym_list = ['"{}"'.format(i) for i in synonym_list]
#     ' OR '.join(synonym_list)
    
#     final = []
#     final.append(' AND '.join(solr_entity))
#     final.append(' OR '.join(semantic_list))
#     final.append(' OR '.join(synonym_list))
#     final = [i for i in final if i]
#     solr = ' OR '.join(final)
    
#     return solr
    

def solr_q(query_ip):
    entity_list = query_ip['information']
    if entity_list:
        if type(entity_list[0])==str:
            entity_list = [entity_list]
    else:
        pass
    s_list = query_ip['abbreviation']
    s_list1 = list(s_list.values())
    if s_list1:
        semantic_list = s_list1[0]
    else:
        semantic_list = []
    synonym_list = query_ip['synonyms']
    solr_entity = [i[1] for i in entity_list if len(i[1].strip())>1]
    solr_entity = list(set(solr_entity))
    solr_entity = [ synonym_list[i] if i in synonym_list else [i] for i in solr_entity]
    solr_entity = [['"{}"'.format(j) for j in i] for i in solr_entity]
    
    semantic_list = ['"{}"'.format(i) for i in semantic_list]
    
    final = []
    for i in solr_entity:
        final.append(' OR '.join(i))
    
    final.append(' OR '.join(semantic_list))
    final = [i for i in final if i]
    final = ['(' + i + ')' for i in final]
    solr = ' AND '.join(final)
    
    return solr
    
    

@app.route('/dygie_inference', methods=['POST'])
def query_ie():
    text = request.get_json()['text']
    text = text.lower()
    
    if len(text.split(' '))>1:
        ## Dygie Output
        dygie_op = entity_relation.predict_query(text=text)
        triples = dygie_op["entity-relation-entity triples"]
        missedTerms = dygie_op["missed_entities"]

        ## RASA Output
        r_inference = nlu_interpreter.parse(text)
        if 'name' in r_inference['intent']:
            r_intent = r_inference['intent']['name']
        else:
            r_intent = ''

        r_classname_entity_lst = []
        for i in r_inference['entities']:
            r_classname_entity_lst.append([i['entity'], i['value']])

        category_entity = []
        for triple in triples:
            term1 = triple[0]
            term2 = triple[2]
            category_entity.extend([term1, term2])

        for missed in missedTerms:
            category_entity.append(missed)

        temp = [i[1] for i in category_entity]
        for rasa_entity in r_classname_entity_lst:
            if rasa_entity[1] not in temp:
                category_entity.append(rasa_entity)

        # To remove duplicate category entity pair
        category_entity = set(map(tuple,category_entity))
        category_entity = list(map(list,category_entity))
        
        print(category_entity)
        op1 = dygie_janusG(text, category_entity)
        op2 = {}
        
        if r_intent == 'abbreviationExplainedBy':
            op2.update(find_abbreviation(text, r_intent, r_classname, r_entity))
            
        elif r_intent == 'ARG1':
            if r_classname == 'Workup':
                s_1 = g.V().has('Workup','value',r_entity).out('ARG1').hasLabel('Other_Compound').values('value').toList()
                if len(s_1)>0:
                    s_1 = [i.strip() for i in s_1]
                    s_1 = [i for i in s_1 if len(i)>1]
                    sem = {'abbreviation':{text:s_1}}
                else:
                    sem = {'abbreviation':{}}
            else:
                sem = {'abbreviation':{}}
            op2.update(sem)
            
        elif r_intent in ['Time', 'Temperature']:
            s_1 = g.V().has('value', r_entity).out().hasLabel(r_intent).values('value').toList()
            if len(s_1)>0:
                sem = {'abbreviation':{text:[s_1[0]]}}
            else:
                sem = {'abbreviation':{}}
            op2.update(sem)
            
        else:
            sem = {'abbreviation':{}}
            op2.update(sem)
            
        op = {**op1, **op2}

        op["information"] = category_entity
        #aid = accoladeID_sen(text, r_inference)
        #op['accolade_id'] = aid
        #op["url"] = extract_url(category_entity)
        url_df = extract_url(category_entity)
        if len(url_df)>0:
            op['urls'] = list(url_df['doc_url'])
        else:
            op['urls'] = []
        aid = accolade1(url_df)
        op['accolade_id'] = aid
        op['entity_property'] = chemical_property(category_entity)
        op['search_recommendation'] = search_recommendation1(category_entity)
    else:
        op = janusG(text)
        op['abbreviation'] = {}
        aid = accolade(text)
        op['accolade_id'] = aid
        #op["url"] = extract_url([['', text]])
        url_df = extract_url([['', text]])
        if len(url_df)>0:
            op['urls'] = list(url_df['doc_url'])
        else:
            op['urls'] = []
        
        cp_input = op['information']
        if cp_input:
            op['entity_property'] = chemical_property([cp_input])
            op['search_recommendation'] = search_recommendation1([cp_input])
        else:
            op['entity_property'] = chemical_property(cp_input)
            op['search_recommendation'] = search_recommendation1(cp_input)
    solr_query = solr_q(op)
    op['solr_query'] = solr_query
    return jsonify(op)

if __name__=='__main__':
    app.run(host='d02ycdpedg001.sabic.com', port=8114, threaded=True)
    # app.run(host='127.0.0.1', port=4949, threaded=True)





