from flask import Flask, request, redirect, url_for, flash, jsonify
from dygie.query_ie import entity_relation
import pandas as pd
import numpy as np
from functools import reduce
import json
from fetch_image_hdfs import get_resource,getDirName, mapFilePath, getFileNames, getImage, pathTofile, encode_to_base, delete_img

import scispacy
import spacy
nlp_pos = spacy.load("en_core_sci_sm")


from gremlin_python.process.anonymous_traversal import traversal
from gremlin_python.process.traversal import T
from gremlin_python.process.traversal import TextP
from gremlin_python.process.graph_traversal import __
from gremlin_python.driver.driver_remote_connection import DriverRemoteConnection

from gremlin_python.process.anonymous_traversal import traversal
from gremlin_python.driver.driver_remote_connection import DriverRemoteConnection
from tornado import httpclient
my_req = httpclient.HTTPRequest('wss://d02ycdpwrk002.sabic.com:8182/gremlin', ca_certs="/home/hadoop/artifacts/truststore.pem")
conn1 = traversal().withRemote(DriverRemoteConnection(my_req,'UAT_A_traversal',username='baskaranj',password='Sabic@2020'))
#conn2 = traversal().withRemote(DriverRemoteConnection(my_req,'UAT-A2_traversal',username='baskaranj',password='Sabic@2020'))


##reading configuration settings
with open('./conf.txt', 'r') as f_conf:
    conf = f_conf.read()
conf_dict = json.loads(conf)  
gremlin_conn_url = conf_dict['gremlin_conn_url']
graph_name = conf_dict['graph_name'] + '_traversal'
app_url = conf_dict['app_url']
app_port = conf_dict['app_port']
rasa_model_path = conf_dict['rasa_model_path']

#g = traversal().withRemote(DriverRemoteConnection(gremlin_conn_url, graph_name))

import pathlib
from rasa.cli.utils import get_validated_path
from rasa.model import get_model, get_model_subdirectories
from rasa.nlu.model import Interpreter
from rasa.shared.nlu.training_data.message import Message
from rasa.shared.nlu.constants import TEXT

app = Flask(__name__)

def load_interpreter(model_path):
    """
    This loads the Rasa NLU interpreter. It is able to apply all NLU
    pipeline steps to a text that you provide it.
    """
    model = get_validated_path(model_path, "model")
    model_path = get_model(model)
    _, nlu_model = get_model_subdirectories(model_path)
    return Interpreter.load(nlu_model)

nlu_interpreter = load_interpreter(rasa_model_path)

def search_recommendation20(g, df1, entity_list):
    try:
        if len(df1)>0:
        
            entity_list = [i for i in entity_list if len(i[1].strip())>1]
            q2 = [[i[0], g.V().has('vClass', i[0]).out('rdfs:isAuthorOf').dedup().path().by(__.valueMap(True)).toList()] if i[0]=='Author_Role' else [i[0], g.V().has('vClass', i[0]).out('isFoundIn').dedup().path().by(__.valueMap(True)).toList()]  for i in entity_list]
            q2 = [i for i in q2 if len(i[1])>0]
            def data_df2(q2_lst):
                lst2 = []
                for i in q2_lst:
                    df_dict2 = {}
                    df_dict2['class_value'] = i[0]['value'][0]
                    df_dict2['doc_vertex_id'] = i[1][T.id]              
                    lst2.append(df_dict2)
                    
                df2 = pd.DataFrame(lst2)
                return df2
            
            df2_lst = [[i[0], data_df2(i[1])] for i in q2]
            
            r_entity = [i[1] for i in entity_list]
            r_entity.extend(['unknown'])
            recommend_lst = {}
            for class_name, df2 in df2_lst:
                if (len(df2)>0):
                    merged_df = pd.merge(df1, df2, on = 'doc_vertex_id')
                    if len(merged_df)>0:
                        recommend = [[n,len(i)] for n,i in merged_df.groupby('class_value')]
                        recommend = sorted(recommend, key = lambda x: -x[1])                        
                        recommend = [i[0] for i in recommend]
                        recommend = [i for i in recommend if i not in r_entity]
                        recommend = [i for i in recommend if len(i.strip())>1]
                        recommend = [i for n,i in enumerate(recommend) if n<5]
                        if recommend:
                            recommend_lst.update({class_name:recommend})
        else:
            recommend_lst = {}
    except:
        recommend_lst = {}
            
    return recommend_lst

def search_recommendation2(g, df1, entity_list):
    try:
        if len(df1)>0:
        
            entity_list = [i for i in entity_list if len(i[1].strip())>1]
            q2 = [g.V().has('vClass', i[0]).out('rdfs:isAuthorOf').dedup().path().by(__.valueMap(True)).toList() if i[0]=='Author_Role' else g.V().has('vClass', i[0]).out('isFoundIn').dedup().path().by(__.valueMap(True)).toList()  for i in entity_list]
            q2 = [i for i in q2 if len(i)>0]
            def data_df2(q2_lst):
                lst2 = []
                for i in q2_lst:
                    df_dict2 = {}
                    df_dict2['class_value'] = i[0]['value'][0]
                    df_dict2['doc_vertex_id'] = i[1][T.id]              
                    lst2.append(df_dict2)
                    
                df2 = pd.DataFrame(lst2)
                return df2
            
            df2_lst = [data_df2(i) for i in q2]
            
            r_entity = [i[1] for i in entity_list]
            r_entity.extend(['unknown'])
            recommend_lst = []
            for df2 in df2_lst:
                if (len(df2)>0):
                    merged_df = pd.merge(df1, df2, on = 'doc_vertex_id')
                    if len(merged_df)>0:
                        recommend = [[n,len(i)] for n,i in merged_df.groupby('class_value')]
                        recommend = sorted(recommend, key = lambda x: -x[1])
                        recommend = [i[0] for i in recommend]
                        recommend = [i for i in recommend if i not in ['unknown', r_entity]]
                        recommend = [i for i in recommend if len(i.strip())>1]
                        recommend = [i for n,i in enumerate(recommend) if n<5]
                        recommend_lst.extend(recommend)
        else:
            recommend_lst = []
    except:
        recommend_lst = []
            
    return recommend_lst

    
def search_recommendation3(g, entity_list):
    try:
        entity_list = [i for i in entity_list if len(i[1].strip())>1]
        c_name = entity_list[0][0]
        e_name = entity_list[0][1]
        print('****##@$')
        print(c_name)
        print(e_name)
        if c_name == 'Author_Role':
            recommend = g.V().has(c_name,'value', e_name).out('rdfs:isAuthorOf').inE('rdfs:isAuthorOf').has('eClass', c_name).outV().groupCount().by('value').toList()[0]
        else:
            recommend = g.V().has(c_name,'value', e_name).out('isFoundIn').inE('isFoundIn').has('eClass', c_name).outV().groupCount().by('value').toList()[0]
        recommend = dict(sorted(recommend.items(), key=lambda item: -item[1]))
        recommend = [k for k,v in recommend.items()]
        recommend = [i.strip('-| ') for i in recommend]
        recommend = [i for i in recommend if i not in ['unknown', e_name]]
        recommend = [i for i in recommend if len(i.strip())>1]
        recommend = [i for n,i in enumerate(recommend) if n<5]
        recommend_lst = recommend
        
    except:
        recommend_lst = []
    return recommend_lst

def chemical_property(g, entity_list):
    if entity_list:
        entity_list = [i for i in entity_list if i[0] == 'Chemical_Entity']
        entity_list = [i[1] for i in entity_list if len(i[1].strip())>1]
        entity_list = list(set(entity_list))
        prop = [[i, g.V().has('Chemical_Entity' ,'value', i).valueMap(True).toList()] for i in entity_list]
        
        prop_lst = []
        for p in prop:
            if p[1]:
                b = {k:v[0] for k,v in p[1][0].items() if k not in [T.id, T.label, 'iri', 'vClass', 'value']} 
                b['prop_synonyms'] = b['prop_other_names']
                b = {k:v for k,v in b.items() if v!= 'Unavailable'} 
                prop_lst.append([p[0], b])    
            else:
                pass
    else:
        prop_lst = []
    return prop_lst
    
    

def janusG(g, term):    
    a = g.V().has('value', term).values('prop_other_names', 'prop_preferred_names').toList()  
    
    if a:
        a = [i.split('; ') for i in a]
        a = [j for i in a for j in i]
        a.append(term)
        b = list(set(a))
        output = {'altValue': b, 'synonyms': {term: b}, 'information':['Chemical_Entity', term]}
    else:
        output = {'altValue': [], 'synonyms': {}, 'information':[]}
    return output

def dygie_janusG(g, category_entity):
    term_list = category_entity
    
    if term_list:
        lst = []
        syn = {}
        for term in term_list:
            term = term[1]
            a = g.V().has('value', term).values('prop_other_names', 'prop_preferred_names').toList()
        
            if a:
                a = [i.split('; ') for i in a]
                a = [j for i in a for j in i]
                a.append(term)
                b = list(set(a))
                lst.extend(b)
                syn.update({term: b})
        if lst:
            lst = list(set(lst))
            output = {'altValue': lst, 'synonyms':syn}
        else:
            output = {'altValue': [], 'synonyms': {}}

    else:
        output = {'altValue': [], 'synonyms': {}}

    return output




def find_abbreviation(g, abb_entity_lst):    
    abb_dict = {i[1]:g.V().has('Abbreviation','value',i[1]).out('abbreviationExplainedBy').values('value').toList() for i in abb_entity_lst}
    abb_dict = {k:v for k,v in abb_dict.items() if v}
    abb = {'abbreviation':abb_dict}    
    return abb


def extract_url(g, entity_list):
    entity_list = [i for i in entity_list if len(i[1].strip())>1]
    query = [g.V().has('value', i[1]).out('rdfs:isAuthorOf').dedup().path().by(__.valueMap(True)).toList() if i[0]=='Author_Role' else g.V().has('value', i[1]).out('isFoundIn').dedup().path().by(__.valueMap(True)).toList()  for i in entity_list]
    query = [i for i in query if i]
    
    m_lst = []
    for q in query:
        t_lst = []
        for i in q:
            tdf_dict = {}
            tdf_dict['doc_vertex_id'] = i[1][T.id]
            tdf_dict['doc_url'] = i[1]['url'][0]
            t_lst.append(tdf_dict)
            
        m_lst.append(pd.DataFrame(t_lst))
    if m_lst:        
        df_merged = reduce(lambda  left,right: pd.merge(left,right,on=['doc_vertex_id', 'doc_url'],how='inner'), m_lst)
    else:
        df_merged = pd.DataFrame()
    return df_merged

def accolade1(g, df1):
    q2 = g.V().has('vClass', 'Accolade_ID').out('isFoundIn').dedup().path().by(__.valueMap(True)).toList()
     
    lst2 = []
    for i in q2:
        df_dict2 = {}
        df_dict2['accolade_id'] = i[0]['value'][0]
        df_dict2['doc_vertex_id'] = i[1][T.id]
        lst2.append(df_dict2)
        
    df2 = pd.DataFrame(lst2)
    if (len(df1)>0) & (len(df2)>0):
        merged_df = pd.merge(df1, df2, on = 'doc_vertex_id')
        if len(merged_df)>0:
            accolade_op = [[n, len(i), list(i['doc_url']), accolade_property(g, n)] for n,i in merged_df.groupby('accolade_id')]
        else:
            accolade_op = []
    else:
        accolade_op = []
        
    return accolade_op


def accolade_property(g, acc_id):
    a = g.V().has('Accolade_ID' ,'value', acc_id).valueMap(True).toList()
    a = a[0]
    if len(a)==0:
        a = {}
    else: 
        pass
    if 'projectName' in a.keys():
        acc_prop = {k:v[0] for k,v in a.items() if k in ['projectUrl', 'projectCreationDate', 'projectDescription', 'projectCurrentStageName', 'projectLeaderName', 'projectName']}
        acc_prop['AccoladeID'] = acc_id
    else:
        acc_prop = {'AccoladeID': acc_id, 'projectUrl': 'not available', 'projectCreationDate': 'not available', 'projectDescription': 'not available', 'projectCurrentStageName': 'not available', 'projectLeaderName': 'not available', 'projectName': 'not available'}
    return acc_prop


def solr_q(query_ip, pos_entity):
    entity_list = query_ip['information']
    if entity_list:
        if type(entity_list[0])==str:
            entity_list = [entity_list]
    else:
        pass
    s_list = query_ip['abbreviation']
    s_list1 = list(s_list.values())
    if s_list1:
        semantic_list = s_list1[0]
    else:
        semantic_list = []
    synonym_list = query_ip['synonyms']
    solr_entity = [i[1] for i in entity_list if len(i[1].strip())>1]
    solr_entity = list(set(solr_entity))
    solr_entity = [ synonym_list[i] if i in synonym_list else [i] for i in solr_entity]
    solr_entity = [['"{}"'.format(j) for j in i] for i in solr_entity]
    
    semantic_list = ['"{}"'.format(i) for i in semantic_list]    
    
    final = []
    for i in solr_entity:
        final.append(' OR '.join(i))
    
    final.append(' OR '.join(semantic_list))
    final = [i for i in final if i]
    final = ['(' + i + ')' for i in final]
    solr = ' AND '.join(final)

    if pos_entity:
        pos_ent = ['"{}"'.format(i[1]) for i in pos_entity]
        pos_ent = ['(' + i + ')'  for i in pos_ent]
        pos_solr = ' AND '.join(pos_ent)
        if solr:
            solr = solr + ' AND ' + pos_solr
        else:
            solr = pos_solr
    
    return solr
    
    

@app.route('/dygie_inference', methods=['POST'])
def query_ie():
    text = request.get_json()['text']
    text = text.lower()
    g = conn1
    print(text)

    if len(text.split(' '))>1:
        ## Dygie Output
        dygie_op = entity_relation.predict_query(text=text)
        triples = dygie_op["entity-relation-entity triples"]
        missedTerms = dygie_op["missed_entities"]
        print("Dygie Output:", dygie_op)
        print("\n")

        ## RASA Output
        r_inference = nlu_interpreter.parse(text)
        print("RASA Output:", r_inference)
        print("\n")

        if 'name' in r_inference['intent']:
            r_intent = r_inference['intent']['name']
        else:
            r_intent = ''
        
        r_classname_entity_lst = []
        for i in r_inference['entities']:
            r_classname_entity_lst.append([i['entity'], i['value']])
        
        category_entity = []
        for triple in triples:
            term1 = triple[0]
            term2 = triple[2]
            category_entity.extend([term1, term2])

        for missed in missedTerms:
            category_entity.append(missed)
        
        temp = [i[1] for i in category_entity]
        for rasa_entity in r_classname_entity_lst:
            if rasa_entity[1] not in temp:
                category_entity.append(rasa_entity)

        temp1 = [i[1] for i in category_entity]
        pos_doc = nlp_pos(text)
        sspacy_entity0 = list(pos_doc.ents)
        sspacy_entity = []
        for ii in sspacy_entity0:
            sspacy_entity.extend(str(ii).split(' '))
        sspacy_entity = list(set(sspacy_entity))
        print("Spacy Entity:", sspacy_entity)
        print("\n")

        sspacy_entity = [['Spacy_Entity', str(i)] for i in sspacy_entity]
        sspacy_entity = [i for i in sspacy_entity if i[1] not in temp1]
        category_entity.extend(sspacy_entity)

        # To remove duplicate category entity pair
        category_entity = set(map(tuple,category_entity))
        category_entity = list(map(list,category_entity))
        
        temp2 = [i[1] for i in category_entity]
        #pos_doc = nlp_pos(text)
        pos_entity = [["POS", str(token)] for token in pos_doc if token.pos_ in ["NOUN", "PROPN"]]
        pos_entity = [i for i in pos_entity if i[1] not in temp2]
        pos_entity_test = [[str(token), token.pos_] for token in pos_doc if token.pos_ in ["NOUN", "PROPN"]]
        print("Spacy POS:", pos_entity_test)
        print("\n")

        op1 = dygie_janusG(g, category_entity)
        op2 = {}
        
        if r_intent == 'abbreviationExplainedBy':
            abb_entity_lst = [i for i in r_classname_entity_lst if i[0] == 'Abbreviation']
            op2.update(find_abbreviation(g, abb_entity_lst))
            
        elif r_intent == 'ARG1':
            abb_entity_lst = [i for i in r_classname_entity_lst if i[0] == 'Workup']
            ans_lst = []
            for i in abb_entity_lst:
                s_1 = g.V().has('Workup','value',i[1]).out('ARG1').hasLabel('Other_Compound').values('value').toList()
                if len(s_1)>0:
                    s_1 = [i.strip() for i in s_1]
                    s_1 = [i for i in s_1 if len(i)>1]
                    ans_lst.extend(s_1)
            
            if ans_lst:
                sem = {'abbreviation':{text:ans_lst}}
            else:
                sem = {'abbreviation':{}}
            
            op2.update(sem)
            
        elif r_intent in ['Time', 'Temperature']:
            ans_lst = []
            for i in r_classname_entity_lst:
                s_1 = g.V().has('value', i[1]).out().hasLabel(r_intent).values('value').toList()
                if len(s_1)>0:
                    ans_lst.extend(s_1)
            if ans_lst:
                sem = {'abbreviation':{text:ans_lst}}
            else:
                sem = {'abbreviation':{}}
            
            op2.update(sem)
            
        else:
            sem = {'abbreviation':{}}
            op2.update(sem)
            
        op = {**op1, **op2}

        op["information"] = category_entity
        url_df = extract_url(g, category_entity)
        if len(url_df)>0:
            op['urls'] = list(url_df['doc_url'])
        else:
            op['urls'] = []
        aid = accolade1(g, url_df)
        op['accolade_id'] = aid
        op['entity_property'] = chemical_property(g, category_entity)
        #op['search_recommendation'] = search_recommendation2(g, url_df, category_entity)
        op['search_recommendation'] = search_recommendation3(g, category_entity)
    else:
        pos_entity = []
        op = janusG(g, text)
        op['abbreviation'] = {}
        url_df = extract_url(g, [['', text]])
        if len(url_df)>0:
            op['urls'] = list(url_df['doc_url'])
        else:
            op['urls'] = []
        aid = accolade1(g, url_df)
        op['accolade_id'] = aid
        
        cp_input = op['information']
        if cp_input:
            op['entity_property'] = chemical_property(g, [cp_input])
            #op['search_recommendation'] = search_recommendation2(g, url_df, [cp_input])
            op['search_recommendation'] = search_recommendation3(g, [cp_input])
        else:
            op['entity_property'] = chemical_property(g, cp_input)
            #op['search_recommendation'] = search_recommendation2(g, url_df, cp_input)
            op['search_recommendation'] = search_recommendation3(g, cp_input)
    solr_query = solr_q(op, pos_entity)
    op['solr_query'] = solr_query
    print("Synonyms:", op['synonyms'])
    print("\n")
    print("Answers:", op['abbreviation'])
    print("\n")
    print("Solr Qoery:", solr_query)
    print("**************************************************************************************************")
    return jsonify(op)

@app.route('/image_fetch', methods = ['POST'])
def index():
    doc_key = request.get_json()['doc_key']

    resource,filename = get_resource(doc_key)
    #print(f'resource name {resource} and filename is {filename}')
    dirname = getDirName(filename)
    #print(f'directory name is {dirname}')
    files = getFileNames(resource,dirname)
    #print(f'all the data {files}')
    img_files = mapFilePath(files)
    #print(f'all the image file name{img_files}')
    img_download = getImage(img_files[0])
    #print("Image downloaded")
    img_path,img_filename = pathTofile(img_files[0])
    #print(f'image pathbis {img_path} and img file name is {img_filename}')
    base64=encode_to_base(img_filename)
    #print(f'base code value {base64}')
    delete_img(img_filename)
    #print('Image delted')
    #img_files = [i.decode('utf-8').strip() for i in img_files]
    res ={"files" : img_files, "base64" : base64.decode('utf-8')}
    #print(f'fina response {res}')
    return jsonify(res)

@app.route('/adhoc', methods = ['POST'])
def index1():
    doc_key = request.get_json()['doc_key']   
    img_download = getImage(doc_key)
    #print("Image downloaded")
    img_path,img_filename = pathTofile(doc_key)
    #print(f'image pathbis {img_path} and img file name is {img_filename}')
    base64=encode_to_base(img_filename)
    #print(f'base code value {base64}')
    delete_img(img_filename)
    #print('Image delted')
    res ={ "base64" : base64.decode('utf-8')}
    #print(f'fina response {res}')
    return jsonify(res)

if __name__=='__main__':
    #app.run(host='127.0.0.1', port=4949, threaded=True)
    app.run(host=app_url, port=app_port, threaded=True)





